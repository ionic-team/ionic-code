/**
 * @private
 */
export declare class ClickBlock {
    enable(): void;
    show(shouldShow: any, expire: any): void;
}
