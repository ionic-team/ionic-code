/**
 * @private
 */
export declare class ClickBlock {
    private _enabled;
    enable(): void;
    show(shouldShow: any, expire: any): void;
}
