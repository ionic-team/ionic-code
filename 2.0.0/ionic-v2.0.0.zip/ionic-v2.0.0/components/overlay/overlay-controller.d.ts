/**
 * @private
 */
export declare class OverlayController {
    open(componentType: any, params?: {}, opts?: {}): any;
    getByType(overlayType: any): any;
    getByHandle(handle: any, overlayType: any): any;
}
