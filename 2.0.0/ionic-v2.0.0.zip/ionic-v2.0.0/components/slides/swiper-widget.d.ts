export declare function Swiper(container: any, params: any): any;
