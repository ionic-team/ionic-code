export declare class ListVirtualScroll {
    constructor(list: any);
    resize(): void;
    _handleVirtualScroll(event: any): void;
    cellAtIndex(index: any): void;
}
