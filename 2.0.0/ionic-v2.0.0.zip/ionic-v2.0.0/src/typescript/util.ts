import * as domUtil from 'ionic/util/dom'
export const dom = domUtil

export * from 'ionic/util/util'
