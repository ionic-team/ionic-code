/**
 * @private
 */
export declare function ConfigComponent(config: any): (cls: any) => any;
