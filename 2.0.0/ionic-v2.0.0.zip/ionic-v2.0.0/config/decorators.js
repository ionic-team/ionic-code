function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./decorators/config-component'));
__export(require('./decorators/app'));
__export(require('./decorators/page'));