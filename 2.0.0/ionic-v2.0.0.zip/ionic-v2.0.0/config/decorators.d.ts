export * from './decorators/config-component';
export * from './decorators/app';
export * from './decorators/page';
