export declare class ScrollTo {
    constructor(ele: any, x: any, y: any, duration: any);
    start(x: any, y: any, duration: any, tolerance: any): any;
    stop(): void;
    dispose(): void;
}
