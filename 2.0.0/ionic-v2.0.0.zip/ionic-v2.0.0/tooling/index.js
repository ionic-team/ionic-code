var Generate = require('./generate');
module.exports = {
  Generate: Generate,
  generate: Generate.generate
};
