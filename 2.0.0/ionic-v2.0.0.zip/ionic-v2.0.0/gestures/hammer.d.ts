/**
 * Simple way to create an manager with a default set of recognizers.
 * @param {HTMLElement} element
 * @param {Object} [options]
 * @constructor
 */
declare function Hammer(element: any, options: any): any;
export { Hammer };
